import numpy as np
import statistics
from CIFO_PROJECT.charles.albert import Individual, Population


very_easy_ =  '0 0 8 1 0 0 4 0 6 0 2 0 0 0 0 0 0 3 0 0 3 0 0 0 0 0 0 9 0 0 0 3 5 0 0 0 0 0 0 0 0 2 0 7 0 4 0 2 8 6 0 0 9 0 0 0 6 0 4 8 0 0 1 0 8 0 2 0 0 6 0 9 5 1 4 0 0 0 8 0 0'
easy =  '0 5 0 0 2 0 0 0 0 0 1 0 0 8 7 0 0 0 0 3 4 0 0 0 0 0 9 0 0 0 0 1 0 0 3 7 0 0 8 0 0 5 0 0 2 3 0 2 7 6 0 0 1 0 0 0 9 0 0 0 8 0 1 7 0 0 6 0 0 0 4 0 0 6 0 2 0 0 0 0 0'
moderate = '2 0 0 8 0 0 0 0 0 0 8 4 0 3 5 0 0 9 1 0 0 0 2 0 4 0 0 0 0 0 7 0 9 0 3 0 3 0 8 0 0 6 0 0 0 0 0 1 0 0 0 0 6 8 0 5 0 3 0 0 6 1 0 0 0 0 0 0 0 0 0 5 0 1 6 0 9 0 7 0 0'
hard =  '0 0 0 0 0 0 7 0 8 0 0 2 0 6 0 0 4 0 0 0 4 0 1 0 0 6 2 5 0 1 0 0 0 0 8 0 0 6 0 8 0 9 0 0 4 0 3 0 0 0 0 5 0 0 0 0 0 6 0 0 0 0 0 0 5 0 0 3 0 0 0 0 0 0 0 0 0 2 0 0 9'


#cues_list = [very_easy_, easy, moderate, hard]

def make_matrix(cues):
    cues = cues.split(' ')
    cues = ''.join(cues)
    cues = np.array(list(map(int, cues)))
    cues = cues.reshape((9,9))
    given_index = np.where(cues != 0)
    given_index = list(zip(given_index[0],given_index[1]))
    to_fill_index = np.where(cues == 0)
    to_fill_index = list(zip(to_fill_index[0],to_fill_index[1]))
    return cues, given_index, to_fill_index



#(very_easy,ve_cues, ve_to_fill), (easy,easy_cues,easy_to_fill), (moderate,moderate_cues, moderate_to_fill), \
#(hard,hard_cues, hard_to_fill) = [make_matrix(i) for i in cues_list]

def list_flatten(list):
    return [item for sublist in list for item in sublist]

def repeated_by_row(matrix):
    unique_counts= []
    row_fitness = 0
    for i in range(0, 9):
        unique, counts = np.unique(matrix[i], return_counts=True)
        #print('unique \n', unique)
        #print('counts \n', counts)
        unique_counts.append(np.array((unique, counts)).T)
    row_count_array = np.array(list_flatten(unique_counts))
    for i in row_count_array:
        row_fitness += (i[1] - 1)

    return unique_counts, row_fitness


def repeated_by_col(matrix):
    unique_counts=[]
    column_fitness = 0
    matrix = matrix.T
    for i in range(0, 9):
        unique, counts = np.unique(matrix[i], return_counts=True)
        #unique_counts.append(np.array(list(zip(unique, counts))))
        #unique_counts_array = np.array(flatten(column_counts_hard))
        unique_counts.append(np.asarray((unique, counts)).T)
    column_count_array = np.array(list_flatten(unique_counts))
    for i in column_count_array:
        column_fitness += (i[1]-1)

    return unique_counts, column_fitness

def repeated_by_block(matrix):
    block_fitness = 0
    block_count = []
    intermediate = []
    unique_counts = []
    for i in range(0, 9, 3):
        for j in range(0, 9, 3):
            block_count.append(matrix[i][j])
            block_count.append(matrix[i][j + 1])
            block_count.append(matrix[i][j + 2])

            block_count.append(matrix[i + 1][j])
            block_count.append(matrix[i + 1][j + 1])
            block_count.append(matrix[i + 1][j + 2])

            block_count.append(matrix[i + 2][j])
            block_count.append(matrix[i + 2][j + 1])
            block_count.append(matrix[i + 2][j + 2])

            intermediate.append(block_count)
            unique, counts = np.unique(np.array(block_count), return_counts = True)
            unique_counts.append(np.asarray((unique, counts)).T)
            block_count = []

    block_count_array = np.array(list_flatten(unique_counts))
    for i in block_count_array:
        block_fitness += (i[1]-1)

    return  unique_counts, block_fitness


def entry_fitness(entry_index, matrix, given_index):
    row_count, row_fitness = repeated_by_row(matrix)
    column_count, column_fitness = repeated_by_col(matrix)
    block_count, block_fitness = repeated_by_block(matrix)
    fitness_entry_row = 0
    fitness_entry_column = 0
    fitness_entry_block = 0
    if entry_index in given_index:
        pass
    else:
        for j in row_count[entry_index[0]]:
            if matrix[entry_index] == j[0]:
                fitness_entry_row += j[1]

        for h in column_count[entry_index[1]]:
            if matrix[entry_index] == h[0]:
                fitness_entry_column += h[1]


        counter = 0
        for g in range(0, 9, 3):
            for h in range(0, 9, 3):

                if (entry_index == (g,h)) | (entry_index == (g,h+1)) | (entry_index == (g,h+2)) | \
                (entry_index == (g+1, h)) | (entry_index == (g+1,h+1)) | (entry_index == (g+1,h+2)) | \
                (entry_index == (g+2, h)) | (entry_index == (g+2,h+1)) | (entry_index == (g+2,h+2)):
                    for k in block_count[counter]:
                        if matrix[entry_index] == k[0]:
                            fitness_entry_block += k[1]
                counter += 1
    entry_fitness = (fitness_entry_column + fitness_entry_row + fitness_entry_block)

    return entry_fitness

Individual.entry_fitness = entry_fitness

def get_fitness(self):
    fitness_individual = []
    indexes = [(i, j) for i in range(9) for j in range(9)]
    for index in indexes:
        if index in self.given_index:
            pass
        else:
            fitness_individual.append(entry_fitness(index,self.representation, self.given_index))
    fit = statistics.mean(fitness_individual)
    return fit


Individual.get_fitness = get_fitness


Pop = Population(size = 20, optim='min', cues = very_easy_)
indiv = Pop.individuals[0].representation
for i in Pop:
    print(i.get_fitness())