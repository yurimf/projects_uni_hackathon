import numpy as np


very_easy_ =  '0 0 8 1 0 0 4 0 6 0 2 0 0 0 0 0 0 3 0 0 3 0 0 0 0 0 0 9 0 0 0 3 5 0 0 0 0 0 0 0 0 2 0 7 0 4 0 2 8 6 0 0 9 0 0 0 6 0 4 8 0 0 1 0 8 0 2 0 0 6 0 9 5 1 4 0 0 0 8 0 0'
easy =  '0 5 0 0 2 0 0 0 0 0 1 0 0 8 7 0 0 0 0 3 4 0 0 0 0 0 9 0 0 0 0 1 0 0 3 7 0 0 8 0 0 5 0 0 2 3 0 2 7 6 0 0 1 0 0 0 9 0 0 0 8 0 1 7 0 0 6 0 0 0 4 0 0 6 0 2 0 0 0 0 0'
moderate = '2 0 0 8 0 0 0 0 0 0 8 4 0 3 5 0 0 9 1 0 0 0 2 0 4 0 0 0 0 0 7 0 9 0 3 0 3 0 8 0 0 6 0 0 0 0 0 1 0 0 0 0 6 8 0 5 0 3 0 0 6 1 0 0 0 0 0 0 0 0 0 5 0 1 6 0 9 0 7 0 0'
hard =  '0 0 0 0 0 0 7 0 8 0 0 2 0 6 0 0 4 0 0 0 4 0 1 0 0 6 2 5 0 1 0 0 0 0 8 0 0 6 0 8 0 9 0 0 4 0 3 0 0 0 0 5 0 0 0 0 0 6 0 0 0 0 0 0 5 0 0 3 0 0 0 0 0 0 0 0 0 2 0 0 9'


cues_list = [very_easy_, easy, moderate, hard]

def make_matrix(cues):
    cues = cues.split(' ')
    cues = ''.join(cues)
    cues = np.array(list(map(int, cues)))
    cues = cues.reshape((9,9))
    given_index = np.where(cues != 0)
    given_index = list(zip(given_index[0],given_index[1]))
    to_fill_index = np.where(cues == 0)
    to_fill_index = list(zip(to_fill_index[0],to_fill_index[1]))
    return cues, given_index, to_fill_index



(very_easy,ve_cues, ve_to_fill), (easy,easy_cues,easy_to_fill), (moderate,moderate_cues, moderate_to_fill), \
(hard,hard_cues, hard_to_fill) = [make_matrix(i) for i in cues_list]

def list_flatten(list):
    return [item for sublist in list for item in sublist]

def repeated_by_row(matrix):
    unique_counts=[]
    row_fitness = 0
    for i in range(0, 9):
        unique, counts = np.unique(matrix[i], return_counts=True)
        unique_counts.append(np.array((unique, counts)).T)
    row_count_array = np.array(list_flatten(unique_counts))
    for i in row_count_array:
        row_fitness += (i[1]-1)
    return unique_counts, row_fitness


def repeated_by_col(matrix):
    unique_counts=[]
    column_fitness = 0
    matrix = matrix.T
    for i in range(0, 9):
        unique, counts = np.unique(matrix[i], return_counts=True)
        unique_counts.append(np.asarray((unique, counts)).T)
    column_count_array = np.array(list_flatten(unique_counts))
    for i in column_count_array:
        print(i)
        column_fitness += (i[1]-1)


    return unique_counts, column_fitness

def repeated_by_block(matrix):
    block_count = np.zeros(9)
    block_sum = 0
    for i in range(0, 9, 3):
        for j in range(0, 9, 3):
            block_count[matrix[i][j] - 1] += 1
            block_count[matrix[i][j + 1] - 1] += 1
            block_count[matrix[i][j + 2] - 1] += 1

            block_count[matrix[i + 1][j] - 1] += 1
            block_count[matrix[i + 1][j + 1] - 1] += 1
            block_count[matrix[i + 1][j + 2] - 1] += 1

            block_count[matrix[i + 2][j] - 1] += 1
            block_count[matrix[i + 2][j + 1] - 1] += 1
            block_count[matrix[i + 2][j + 2] - 1] += 1

            block_sum += (1.0 / len(set(block_count))) / 9
            block_count = np.zeros(9)
    return block_sum, block_count

if __name__ == '__main__':

    print(hard)
    column_counts_hard, column_fitness = repeated_by_col(hard)
    row_counts_hard = repeated_by_row(hard)
    print('col counts \n', column_counts_hard,'\n','row counts \n', row_counts_hard, '\n', 'column fitness \n', column_fitness)


    #cues_,x,v = make_matrix(very_easy_)
    #print(cues_)
    #block_sum, block_count = repeated_by_block(cues_)
    #print('block sum \n', block_sum,'\n','block count \n', block_count)
#Isto não está bem estes repeated by, é preciso corrigir
