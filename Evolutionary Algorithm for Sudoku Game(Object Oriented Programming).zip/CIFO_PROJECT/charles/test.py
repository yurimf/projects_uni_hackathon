for i in range(0,9,3):
    print(i)

test = []
for i in range(0,15):
    test.append(i)

print(list[list[test]])
